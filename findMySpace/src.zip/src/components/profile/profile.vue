<template>
 <div> 
 <naviBarHeader/>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> <!-- cdn não é a melhor forma, mas eu nao lembro como faz com webpack -->
  </div>
</template>

<script>
import naviBarHeader from '../shared/naviBarHeader'
export default {
  components: {
	naviBarHeader
  }  
}
</script>

<style scoped>
</style>