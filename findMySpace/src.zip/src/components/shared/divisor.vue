<template>
  <div>
    <hr class="divisor" />
  </div>
</template>

<script>
export default {}
</script>

<style scoped>

.divisor {
  background-color: #6E5077; 
  height: 1px; 
  border: none;
  margin-top: 25px;
}


</style>